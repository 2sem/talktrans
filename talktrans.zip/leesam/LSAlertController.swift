//
//  LSAlertController.swift
//  talktrans
//
//  Created by 영준 이 on 2016. 12. 2..
//  Copyright © 2016년 leesam. All rights reserved.
//

import UIKit

class LSAlertController: UIAlertController {
    override var shouldAutorotate: Bool{
        get{
            return false;
        }
    }
}

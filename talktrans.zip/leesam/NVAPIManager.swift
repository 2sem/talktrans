//
//  NVAPIManager.swift
//  talktrans
//
//  Created by 영준 이 on 2016. 12. 8..
//  Copyright © 2016년 leesam. All rights reserved.
//

import Foundation
import UIKit

/**
 (1) 기계번역 API가 지원하는 언어 보기
 - 신규: 한국어(ko) <-> 중국어 번체 (zh-TW)
 - 한국어(ko) <-> 중국어 간체 (zh-CN)
 - 한국어(ko) <-> 영어 (en)
 - 한국어(ko) <-> 일어 (ja)
 */
class NVAPIManager : NSObject{
    static let NaverAPIURL = URL(string: "https://openapi.naver.com/v1")!;
    private var infos : [String : [String : String]]{
        get{
            var value : [String : [String : String]] = [:];
            var naverList = Bundle.main.infoDictionary?["NaverAPI"] as? [String : [String : String]];
            guard naverList != nil else{
                print("Add [String : [String : String]] Dictionary as 'NaverAPI' into Info.plist");
                return value;
            }
            
            value = naverList ?? [:];
            
            return value;
        }
    };
    
    private func apiInfo(api : String) -> [String : String]?{
        var value = self.infos[api];
        
        guard value != nil else{
            print("Add dictionary '\(api)' into Info.plist/NaverAPI");
            return value;
        }
        
        return value;
    }
    
    private func clientIDForAPI(api : String) -> String?{
        var value = self.apiInfo(api: api)?["ClientID"];
        
        guard value != nil else{
            print("Add 'ClientID' into Info.plist/NaverAPI/\(api)");
            return value;
        }
        
        return value;
    }
    
    private func clientSecretForAPI(api : String) -> String?{
        var value = self.apiInfo(api: api)?["ClientSecret"];
        
        guard value != nil else{
            print("Add 'ClientSecret' into Info.plist/NaverAPI/\(api)");
            return value;
        }
        
        return value;
    }
    
    static let Languages = ["ko-Kore" : "ko", "ja" : "ja", "en" : "en", "zh-Hans" : "zh-CN", "zh-Hant" : "zh-TW"];
    static let DefaultSourceLang = "ko";
    
    typealias TranslateCompletionHandler = ((Int, String?, NSError?) -> Void);
    
    static func canSupportTranslate(source : Locale, target : Locale) -> Bool{
        return ((source.languageCode == "ko"
            || target.languageCode == "ko")) && (source.identifier != target.identifier);
    }
    
    func requestTranslate(text : String, source : Locale, target : Locale, completionHandler: TranslateCompletionHandler?){
        var url = NVAPIManager.NaverAPIURL;
        url.appendPathComponent("language/translate");
        var req = URLRequest(url:  url);
//        req.addValue("wUTBiotl4oVtbKRQMugI", forHTTPHeaderField: "X-Naver-Client-Id");
        req.addValue(self.clientIDForAPI(api: "Translator") ?? "", forHTTPHeaderField: "X-Naver-Client-Id");
        req.addValue(self.clientSecretForAPI(api: "Translator") ?? "", forHTTPHeaderField: "X-Naver-Client-Secret");
//        req.addValue("j0xS22P7uh", forHTTPHeaderField: "X-Naver-Client-Secret");
        req.addValue("application/json;charset=utf-8", forHTTPHeaderField: "Content-Type");
        req.httpMethod = "POST";
        
        var sourceLang = NVAPIManager.Languages.first(where: { (key: String, value: String) -> Bool in
            return source.identifier.hasPrefix(key);
        })?.value ?? NVAPIManager.DefaultSourceLang;
        var targetLang = NVAPIManager.Languages.first(where: { (key: String, value: String) -> Bool in
            return target.identifier.hasPrefix(key);
        })?.value ?? "en";
        var params = ["source": sourceLang,
                      "target": targetLang, "text": text];
//        req.httpBody = "{\"source\": \"ko\", \"target\": \"en\", \"text\": \"안녕하세요\"}".data(using: .utf8);
//        req.httpBody = "'text': 'siba'".data(using: .utf8);
        var json : String? = "";
        do{
            req.httpBody = try JSONSerialization.data(withJSONObject: params, options: .prettyPrinted);
            json = String(data: req.httpBody!, encoding: .utf8);
//            print("json => \(json)");
        }catch let error{
            print("json error => \(error)");
            return;
        }
        
        print("naver => request \(req) -> \(json ?? "")");
//        UIApplication.shared.isNetworkActivityIndicatorVisible = true;
        URLSession.shared.dataTask(with: req, completionHandler: {(data, res, error) -> Void in
            //let jsonData = data;
            defer{
//                UIApplication.shared.isNetworkActivityIndicatorVisible = false;
            }
            
            var httpRes = res as? HTTPURLResponse;
            guard data != nil else{
                completionHandler?(httpRes?.statusCode ?? 599, nil, error as NSError?);
                return;
            }
            
            var jsonString = String(data: data ?? Data(), encoding: .utf8);
            var dict : [String : NSObject]? = [:];
            var translatedText : String?;
            do{
                var dict = try JSONSerialization.jsonObject(with: data!, options: [JSONSerialization.ReadingOptions.mutableContainers, .allowFragments]) as? [String : NSObject];
                var message = dict?["message"] as? [String : NSObject];
                print("naver response > message > \(message)");
                var result = message?["result"] as? [String : NSObject];
                print("naver response > message > result > \(result)");
                translatedText = result?["translatedText"] as? String;
                print("naver response > message > result > translatedText > \(translatedText)");
            }catch let jsonError{
                
            }
            completionHandler?(httpRes?.statusCode ?? 200, translatedText, error as NSError?);
            print("naver => response \(httpRes?.statusCode) - \(jsonString)");
        }).resume();
    }
    
//    var jsonString : String{
//        get{
//            var value = "";
//            
//            do{
//                let data = try NSJSONSerialization.dataWithJSONObject(self.fields, options: NSJSONWritingOptions.PrettyPrinted);
//                
//                value = String(data: data, encoding: NSUTF8StringEncoding) ?? "";
//            }catch(let error){
//                print("json serialize error. error[\(error)]");
//            }
//            
//            return value;
//        }
//    }
//    
//    static func fromJson(json : String) -> SNFontInfo{
//        var fontInfo = SNFontInfo();
//        
//        do{
//            print("parse font json. json[\(json)]");
//            
//            let data = json.dataUsingEncoding(NSUTF8StringEncoding);
//            let dict = try NSJSONSerialization.JSONObjectWithData(data!, options: [NSJSONReadingOptions.MutableContainers, .AllowFragments]) as? [String : NSObject];
//            
//            fontInfo.fields = dict!;
//            //            value = String(data: data, encoding: NSUTF8StringEncoding) ?? "";
//        }catch(let error){
//            print("font json parsing error occured. error[\(error)]");
//        }
//        
//        return fontInfo;
//    }
}

//
//  LS.swift
//  talktrans
//
//  Created by 영준 이 on 2016. 12. 8..
//  Copyright © 2016년 leesam. All rights reserved.
//

import Foundation

class LS : NSObject{
//    static func async(block: dispatch_block_t){
//        let queue: dispatch_queue_t = dispatch_get_global_queue(QOS_CLASS_BACKGROUND, 0)
//        
//        //        DISPATCH_SOURCE_TYPE_DATA_ADD
//        //        dispatch_source_create(<#T##type: dispatch_source_type_t##dispatch_source_type_t#>, <#T##handle: UInt##UInt#>, <#T##mask: UInt##UInt#>, <#T##queue: dispatch_queue_t!##dispatch_queue_t!#>)
//        //        DISPATCH_QUEUE_CONCURRENT
//        dispatch_async(queue){
//            block();
//        }
//    }
//    
//    static func sync(block: dispatch_block_t){
//        let isMain = dispatch_queue_get_label(dispatch_get_main_queue()) == dispatch_queue_get_label(DISPATCH_CURRENT_QUEUE_LABEL);
//        if !isMain{
//            dispatch_sync(dispatch_get_main_queue()){
//                block();
//            }
//        }else{
//            block();
//        }
//    }
//    
//    static func asyncUI(block: dispatch_block_t){
//        dispatch_async(dispatch_get_main_queue()){
//            block();
//        }
//    }
}
